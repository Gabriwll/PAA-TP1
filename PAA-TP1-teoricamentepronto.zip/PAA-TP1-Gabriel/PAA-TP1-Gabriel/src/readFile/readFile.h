#ifndef READFILE_H
#define READFILE_H
#include <stdbool.h>

bool ler_arquivo(const char *fname, int *sr, int *sc);

#endif
