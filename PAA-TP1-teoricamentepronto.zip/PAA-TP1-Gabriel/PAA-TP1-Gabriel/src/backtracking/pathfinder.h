#ifndef PATHFINDER_H
#define PATHFINDER_H
#include <stdbool.h>

void movimentar(int r, int c, int dur, int pecas, int depth);
void imprimir_solucao(void);

#endif
